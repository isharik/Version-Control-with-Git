# Version-Control-With-Git-Final-Assignment-Command-Line-Solution

Final assignment solution for Coursera course "Version Control with Git" (Using command-line) 

Course link: https://www.coursera.org/learn/version-control-with-git/

Question:
Create a Git repository with the commits shown in the commit graph. This
simulates a team building and releasing a product using the Gitflow workflow. 


NOTE: In the above graph, the left-most branch is the "develop" branch, NOT the "master" branch.
